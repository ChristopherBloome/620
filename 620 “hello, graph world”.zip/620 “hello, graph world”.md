#  Setup Enviorment

### Load YML enviorment.


```python
#conda env create -f sps620env.yml
```

### Activate enviorment


```python
conda activate sps620env
```

    
    Note: you may need to restart the kernel to use updated packages.
    

### Install older pacakges as per professor's instructions / compabatability 


```python
# pip install networkx==1.11 
# pip install matplotlib==2.2.3
```


```python
conda list
```

    # packages in environment at C:\Users\bloom\anaconda3:
    #
    # Name                    Version                   Build  Channel
    _ipyw_jlab_nb_ext_conf    0.1.0                    py37_0  
    alabaster                 0.7.12                   py37_0  
    anaconda                  2020.02                  py37_0  
    anaconda-client           1.7.2                    py37_0  
    anaconda-navigator        1.9.12                   py37_0  
    anaconda-project          0.8.4                      py_0  
    argh                      0.26.2                   py37_0  
    asn1crypto                1.3.0                    py37_0  
    astroid                   2.3.3                    py37_0  
    astropy                   4.0              py37he774522_0  
    atomicwrites              1.3.0                    py37_1  
    attrs                     19.3.0                     py_0  
    autopep8                  1.4.4                      py_0  
    babel                     2.8.0                      py_0  
    backcall                  0.1.0                    py37_0  
    backports                 1.0                        py_2  
    backports.functools_lru_cache 1.6.1                      py_0  
    backports.shutil_get_terminal_size 1.0.0                    py37_2  
    backports.tempfile        1.0                        py_1  
    backports.weakref         1.0.post1                  py_1  
    bcrypt                    3.1.7            py37he774522_0  
    beautifulsoup4            4.8.2                    py37_0  
    bitarray                  1.2.1            py37he774522_0  
    bkcharts                  0.2                      py37_0  
    blas                      1.0                         mkl  
    bleach                    3.1.0                    py37_0  
    blosc                     1.16.3               h7bd577a_0  
    bokeh                     1.4.0                    py37_0  
    boto                      2.49.0                   py37_0  
    bottleneck                1.3.2            py37h2a96729_0  
    brotli                    1.0.9                    pypi_0    pypi
    bzip2                     1.0.8                he774522_0  
    ca-certificates           2020.1.1                      0  
    certifi                   2019.11.28               py37_0  
    cffi                      1.14.0           py37h7a1dbc1_0  
    chardet                   3.0.4                 py37_1003  
    click                     7.0                      py37_0  
    cloudpickle               1.3.0                      py_0  
    clyent                    1.2.2                    py37_1  
    colorama                  0.4.3                      py_0  
    colorcet                  2.0.6              pyhd3eb1b0_0  
    colorlover                0.3.0                      py_0    conda-forge
    comtypes                  1.1.7                    py37_0  
    conda                     4.9.2            py37haa95532_0  
    conda-build               3.18.11                  py37_0  
    conda-env                 2.6.0                         1  
    conda-package-handling    1.6.0            py37h62dcd97_0  
    conda-verify              3.4.2                      py_1  
    console_shortcut          0.1.1                         4  
    contextlib2               0.6.0.post1                py_0  
    cryptography              2.8              py37h7a1dbc1_0  
    curl                      7.68.0               h2a8f88b_0  
    cycler                    0.10.0                   py37_0  
    cython                    0.29.15          py37ha925a31_0  
    cytoolz                   0.10.1           py37he774522_0  
    dash                      1.19.0                   pypi_0    pypi
    dash-core-components      1.15.0                   pypi_0    pypi
    dash-html-components      1.1.2                    pypi_0    pypi
    dash-renderer             1.9.0                    pypi_0    pypi
    dash-table                4.11.2                   pypi_0    pypi
    dask                      2.11.0                     py_0  
    dask-core                 2.11.0                     py_0  
    datashader                0.11.1                     py_0  
    datashape                 0.5.4            py37haa95532_1  
    decorator                 4.4.1                      py_0  
    defusedxml                0.6.0                      py_0  
    diff-match-patch          20181111                   py_0  
    distributed               2.11.0                   py37_0  
    docutils                  0.16                     py37_0  
    entrypoints               0.3                      py37_0  
    et_xmlfile                1.0.1                    py37_0  
    fastcache                 1.1.0            py37he774522_0  
    filelock                  3.0.12                     py_0  
    flake8                    3.7.9                    py37_0  
    flask                     1.1.1                      py_0  
    flask-compress            1.9.0                    pypi_0    pypi
    freetype                  2.9.1                ha9979f8_1  
    fsspec                    0.6.2                      py_0  
    future                    0.18.2                   py37_0  
    get_terminal_size         1.0.0                h38e98db_0  
    gevent                    1.4.0            py37he774522_0  
    glob2                     0.7                        py_0  
    greenlet                  0.4.15           py37hfa6e2cd_0  
    h5py                      2.10.0           py37h5e291fa_0  
    hdf5                      1.10.4               h7ebc959_0  
    heapdict                  1.0.1                      py_0  
    html5lib                  1.0.1                    py37_0  
    hypothesis                5.5.4                      py_0  
    icc_rt                    2019.0.0             h0cc432a_1  
    icu                       58.2                 ha66f8fd_1  
    idna                      2.8                      py37_0  
    imageio                   2.6.1                    py37_0  
    imagesize                 1.2.0                      py_0  
    importlib_metadata        1.5.0                    py37_0  
    intel-openmp              2020.0                      166  
    intervaltree              3.0.2                      py_0  
    ipykernel                 5.1.4            py37h39e3cac_0  
    ipython                   7.12.0           py37h5ca1d4c_0  
    ipython_genutils          0.2.0                    py37_0  
    ipywidgets                7.5.1                      py_0  
    isort                     4.3.21                   py37_0  
    itsdangerous              1.1.0                    py37_0  
    jdcal                     1.4.1                      py_0  
    jedi                      0.14.1                   py37_0  
    jinja2                    2.11.1                     py_0  
    joblib                    0.14.1                     py_0  
    jpeg                      9b                   hb83a4c4_2  
    json5                     0.9.1                      py_0  
    jsonschema                3.2.0                    py37_0  
    jupyter                   1.0.0                    py37_7  
    jupyter_client            5.3.4                    py37_0  
    jupyter_console           6.1.0                      py_0  
    jupyter_core              4.6.1                    py37_0  
    jupyterlab                1.2.6              pyhf63ae98_0  
    jupyterlab_server         1.0.6                      py_0  
    keyring                   21.1.0                   py37_0  
    kiwisolver                1.1.0            py37ha925a31_0  
    krb5                      1.17.1               hc04afaa_0  
    lazy-object-proxy         1.4.3            py37he774522_0  
    libarchive                3.3.3                h0643e63_5  
    libcurl                   7.68.0               h2a8f88b_0  
    libiconv                  1.15                 h1df5818_7  
    liblief                   0.9.0                ha925a31_2  
    libpng                    1.6.37               h2a8f88b_0  
    libsodium                 1.0.16               h9d3ae62_0  
    libspatialindex           1.9.3                h33f27b4_0  
    libssh2                   1.8.2                h7a1dbc1_0  
    libtiff                   4.1.0                h56a325e_0  
    libxml2                   2.9.9                h464c3ec_0  
    libxslt                   1.1.33               h579f668_0  
    llvmlite                  0.31.0           py37ha925a31_0  
    locket                    0.2.0                    py37_1  
    lxml                      4.5.0            py37h1350720_0  
    lz4-c                     1.8.1.2              h2fa13f4_0  
    lzo                       2.10                 h6df0209_2  
    m2w64-gcc-libgfortran     5.3.0                         6  
    m2w64-gcc-libs            5.3.0                         7  
    m2w64-gcc-libs-core       5.3.0                         7  
    m2w64-gmp                 6.1.0                         2  
    m2w64-libwinpthread-git   5.0.0.4634.697f757               2  
    markupsafe                1.1.1            py37he774522_0  
    matplotlib                2.2.3                    pypi_0    pypi
    mccabe                    0.6.1                    py37_1  
    menuinst                  1.4.16           py37he774522_0  
    mistune                   0.8.4            py37he774522_0  
    mkl                       2020.0                      166  
    mkl-service               2.3.0            py37hb782905_0  
    mkl_fft                   1.0.15           py37h14836fe_0  
    mkl_random                1.1.0            py37h675688f_0  
    mock                      4.0.1                      py_0  
    modsimpy                  1.1.3                    pypi_0    pypi
    more-itertools            8.2.0                      py_0  
    mpmath                    1.1.0                    py37_0  
    msgpack-python            0.6.1            py37h74a9793_1  
    msys2-conda-epoch         20160418                      1  
    multipledispatch          0.6.0                    py37_0  
    navigator-updater         0.2.1                    py37_0  
    nbconvert                 5.6.1                    py37_0  
    nbformat                  5.0.4                      py_0  
    networkx                  1.11                     pypi_0    pypi
    nltk                      3.4.5                    py37_0  
    nose                      1.3.7                    py37_2  
    notebook                  6.0.3                    py37_0  
    numba                     0.48.0           py37h47e9c7a_0  
    numexpr                   2.7.1            py37h25d0782_0  
    numpy                     1.18.1           py37h93ca92e_0  
    numpy-base                1.18.1           py37hc3f5095_1  
    numpydoc                  0.9.2                      py_0  
    olefile                   0.46                     py37_0  
    openpyxl                  3.0.3                      py_0  
    openssl                   1.1.1d               he774522_4  
    packaging                 20.1                       py_0  
    pandas                    1.0.1            py37h47e9c7a_0  
    pandoc                    2.2.3.2                       0  
    pandocfilters             1.4.2                    py37_1  
    param                     1.10.1             pyhd3eb1b0_0  
    paramiko                  2.7.1                      py_0  
    parso                     0.5.2                      py_0  
    partd                     1.1.0                      py_0  
    path                      13.1.0                   py37_0  
    path.py                   12.4.0                        0  
    pathlib2                  2.3.5                    py37_0  
    pathtools                 0.1.2                      py_1  
    patsy                     0.5.1                    py37_0  
    pep8                      1.7.1                    py37_0  
    pexpect                   4.8.0                    py37_0  
    pickleshare               0.7.5                    py37_0  
    pillow                    7.0.0            py37hcc1f983_0  
    pint                      0.11                       py_1    conda-forge
    pip                       20.0.2                   py37_1  
    pkginfo                   1.5.0.1                  py37_0  
    plotly                    4.14.3             pyhd3eb1b0_0  
    pluggy                    0.13.1                   py37_0  
    ply                       3.11                     py37_0  
    powershell_shortcut       0.0.1                         3  
    proj                      6.2.1                h9f7ef89_0  
    prometheus_client         0.7.1                      py_0  
    prompt_toolkit            3.0.3                      py_0  
    psutil                    5.6.7            py37he774522_0  
    py                        1.8.1                      py_0  
    py-lief                   0.9.0            py37ha925a31_2  
    pycodestyle               2.5.0                    py37_0  
    pycosat                   0.6.3            py37he774522_0  
    pycparser                 2.19                     py37_0  
    pycrypto                  2.6.1            py37hfa6e2cd_9  
    pyct                      0.4.8                    py37_0  
    pycurl                    7.43.0.5         py37h7a1dbc1_0  
    pydocstyle                4.0.1                      py_0  
    pyflakes                  2.1.1                    py37_0  
    pygments                  2.5.2                      py_0  
    pylint                    2.4.4                    py37_0  
    pynacl                    1.3.0            py37h62dcd97_0  
    pyodbc                    4.0.30           py37ha925a31_0  
    pyopenssl                 19.1.0                   py37_0  
    pyparsing                 2.4.6                      py_0  
    pyproj                    2.6.1.post1      py37hcfa1391_1  
    pyqt                      5.9.2            py37h6538335_2  
    pyreadline                2.1                      py37_1  
    pyrsistent                0.15.7           py37he774522_0  
    pysocks                   1.7.1                    py37_0  
    pytables                  3.6.1            py37h1da0976_0  
    pytest                    5.3.5                    py37_0  
    pytest-arraydiff          0.3              py37h39e3cac_0  
    pytest-astropy            0.8.0                      py_0  
    pytest-astropy-header     0.1.2                      py_0  
    pytest-doctestplus        0.5.0                      py_0  
    pytest-openfiles          0.4.0                      py_0  
    pytest-remotedata         0.3.2                    py37_0  
    python                    3.7.6                h60c2a47_2  
    python-dateutil           2.8.1                      py_0  
    python-jsonrpc-server     0.3.4                      py_0  
    python-language-server    0.31.7                   py37_0  
    python-libarchive-c       2.8                     py37_13  
    python_abi                3.7                     1_cp37m    conda-forge
    pytz                      2019.3                     py_0  
    pywavelets                1.1.1            py37he774522_0  
    pywin32                   227              py37he774522_1  
    pywin32-ctypes            0.2.0                 py37_1000  
    pywinpty                  0.5.7                    py37_0  
    pyyaml                    5.3              py37he774522_0  
    pyzmq                     18.1.1           py37ha925a31_0  
    qdarkstyle                2.8                        py_0  
    qt                        5.9.7            vc14h73c81de_0  
    qtawesome                 0.6.1                      py_0  
    qtconsole                 4.6.0                      py_1  
    qtpy                      1.9.0                      py_0  
    requests                  2.22.0                   py37_1  
    retrying                  1.3.3                    py37_2  
    rope                      0.16.0                     py_0  
    rtree                     0.9.3            py37h21ff451_0  
    ruamel_yaml               0.15.87          py37he774522_0  
    scikit-image              0.16.2           py37h47e9c7a_0  
    scikit-learn              0.22.1           py37h6288b17_0  
    scipy                     1.4.1            py37h9439919_0  
    seaborn                   0.10.0                     py_0  
    send2trash                1.5.0                    py37_0  
    setuptools                45.2.0                   py37_0  
    simplegeneric             0.8.1                    py37_2  
    singledispatch            3.4.0.3                  py37_0  
    sip                       4.19.8           py37h6538335_0  
    six                       1.14.0                   py37_0  
    snappy                    1.1.7                h777316e_3  
    snowballstemmer           2.0.0                      py_0  
    sortedcollections         1.1.2                    py37_0  
    sortedcontainers          2.1.0                    py37_0  
    soupsieve                 1.9.5                    py37_0  
    sphinx                    2.4.0                      py_0  
    sphinxcontrib             1.0                      py37_1  
    sphinxcontrib-applehelp   1.0.1                      py_0  
    sphinxcontrib-devhelp     1.0.1                      py_0  
    sphinxcontrib-htmlhelp    1.0.2                      py_0  
    sphinxcontrib-jsmath      1.0.1                      py_0  
    sphinxcontrib-qthelp      1.0.2                      py_0  
    sphinxcontrib-serializinghtml 1.1.3                      py_0  
    sphinxcontrib-websupport  1.2.0                      py_0  
    spyder                    4.0.1                    py37_0  
    spyder-kernels            1.8.1                    py37_0  
    sqlalchemy                1.3.13           py37he774522_0  
    sqlite                    3.31.1               he774522_0  
    statsmodels               0.11.0           py37he774522_0  
    sympy                     1.5.1                    py37_0  
    tbb                       2020.0               h74a9793_0  
    tblib                     1.6.0                      py_0  
    terminado                 0.8.3                    py37_0  
    testpath                  0.4.4                      py_0  
    tk                        8.6.8                hfa6e2cd_0  
    toolz                     0.10.0                     py_0  
    tornado                   6.0.3            py37he774522_3  
    tqdm                      4.42.1                     py_0  
    traitlets                 4.3.3                    py37_0  
    ujson                     1.35             py37hfa6e2cd_0  
    unicodecsv                0.14.1                   py37_0  
    urllib3                   1.25.8                   py37_0  
    vc                        14.1                 h0510ff6_4  
    vs2015_runtime            14.16.27012          hf0eaf9b_1  
    watchdog                  0.10.2                   py37_0  
    wcwidth                   0.1.8                      py_0  
    webencodings              0.5.1                    py37_1  
    werkzeug                  1.0.0                      py_0  
    wheel                     0.34.2                   py37_0  
    widgetsnbextension        3.5.1                    py37_0  
    win_inet_pton             1.1.0                    py37_0  
    win_unicode_console       0.5                      py37_0  
    wincertstore              0.2                      py37_0  
    winpty                    0.4.3                         4  
    wrapt                     1.11.2           py37he774522_0  
    xarray                    0.16.2             pyhd3eb1b0_0  
    xlrd                      1.2.0                    py37_0  
    xlsxwriter                1.2.7                      py_0  
    xlwings                   0.17.1                   py37_0  
    xlwt                      1.3.0                    py37_0  
    xmltodict                 0.12.0                     py_0  
    xz                        5.2.4                h2fa13f4_4  
    yaml                      0.1.7                hc54c509_2  
    yapf                      0.28.0                     py_0  
    zeromq                    4.3.1                h33f27b4_3  
    zict                      1.0.0                      py_0  
    zipp                      2.2.0                      py_0  
    zlib                      1.2.11               h62dcd97_3  
    zstd                      1.3.7                h508b16e_0  
    
    Note: you may need to restart the kernel to use updated packages.
    

# Plot Basic Graph


```python
import networkx as nx
import matplotlib.pyplot as plt
```


```python
G=nx.Graph()
G.add_nodes_from([1,2,3,4,5,6,7,8])
G.add_edges_from([(1,2),(2,8),(2,4),(2,5),(3,6),(3,7),(8,3)])
nx.draw(G)
```


![png](output_10_0.png)



```python

```
